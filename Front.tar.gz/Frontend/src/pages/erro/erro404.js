import React from 'react';

// import { Container } from './styles';

export default function Erro404() {
  return (
    <h1 style={{textAlign: 'center'}}>Erro 404, página não encontrada!</h1>
  );
}
