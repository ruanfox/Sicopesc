import cpfMask from "./cpf";
import nitMask from "./nit";
import ceiMask from "./cei";
import cepMask from "./cep";
import tituloMask from "./titulo";

export { cpfMask, nitMask, ceiMask, cepMask, tituloMask };
