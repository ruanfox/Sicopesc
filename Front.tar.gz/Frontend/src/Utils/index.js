export function dateFormat(date) {
  let data = new Date(date);
  data.setDate(data.getDate() + 1);
  return data.toLocaleDateString();
}
export function formatDate(date) {
  var d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();

  if (month.length < 2) 
      month = '0' + month;
  if (day.length < 2) 
      day = '0' + day;

  return [year, month, day].join('-');
}