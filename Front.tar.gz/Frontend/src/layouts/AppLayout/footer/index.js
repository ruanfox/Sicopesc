import React from "react";

// import { Container } from './styles';

export default function Footer() {
  return (
    <footer className="page-footer white z-depth-2">
      <div className="container-fluid text-color">© 2019 - 2021</div>
    </footer>
  );
}
