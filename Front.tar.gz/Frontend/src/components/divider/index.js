import React from 'react';
import {Container} from './styles'

export default function divider(){

    return <Container className="divider"><div></div></Container>;
}